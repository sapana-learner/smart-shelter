import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  MapPin, Thermometer, Sun, Wind, Droplets, Ruler, Compass, Layers,
  Home, ArrowRight, ArrowLeft, Loader2, Lightbulb, RotateCcw,
  CheckCircle2, Circle, TriangleAlert, Gauge, Zap, TrendingDown, ChevronRight
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  RadialBarChart, RadialBar, PolarAngleAxis, AreaChart, Area
} from "recharts";

/* ------------------------------------------------------------------ */
/*  Design tokens                                                      */
/* ------------------------------------------------------------------ */
const T = {
  navy950: "#0A131A",
  navy900: "#0F1D25",
  navy800: "#16262F",
  line800: "#22343F",
  ice300: "#A9E8F0",
  ice400: "#5FC7D6",
  ice500: "#3AA9BA",
  amber500: "#E7A23A",
  amber600: "#C9852220",
  bgApp: "#EFF3F4",
  surface: "#FFFFFF",
  surfaceAlt: "#E7EDEE",
  text900: "#122029",
  text600: "#54666F",
  text400: "#8DA0A8",
  good: "#4C9A6A",
  warn: "#D98B2B",
};

const STEPS = [
  { id: 1, label: "Location", icon: MapPin },
  { id: 2, label: "Climate", icon: Thermometer },
  { id: 3, label: "Shelter Design", icon: Ruler },
  { id: 4, label: "Simulation", icon: Gauge },
  { id: 5, label: "Recommendation", icon: Lightbulb },
];

const LOCATIONS = ["Ladakh", "Leh", "Manali", "Srinagar", "Spiti Valley"];

const CLIMATE_PRESETS = {
  Ladakh: { temp: -10, solar: 650, wind: 8, humidity: 30 },
  Leh: { temp: -8, solar: 630, wind: 7, humidity: 32 },
  Manali: { temp: 2, solar: 480, wind: 5, humidity: 55 },
  Srinagar: { temp: 0, solar: 450, wind: 4, humidity: 60 },
  "Spiti Valley": { temp: -12, solar: 670, wind: 9, humidity: 25 },
};

const WALL_TYPES = ["Insulated Panel", "Brick with Cavity", "Rammed Earth", "Timber Frame"];
const ROOF_TYPES = ["Insulated Roof", "Metal Sheet", "Flat Concrete"];
const ORIENTATIONS = ["South", "East", "West", "North"];

const WALL_MULTIPLIER = {
  "Insulated Panel": 1.0,
  "Brick with Cavity": 1.3,
  "Rammed Earth": 1.55,
  "Timber Frame": 1.2,
};

const ORIENTATION_GAIN = { South: 0.9, East: 0.7, West: 0.7, North: 0.4 };

/* ------------------------------------------------------------------ */
/*  Engineering calculations (simplified, for demonstration)           */
/* ------------------------------------------------------------------ */
function computeSimulation(climate, shelter) {
  const { length, width, height, orientation, wall, insulation } = shelter;
  const floorArea = length * width;
  const volume = length * width * height;
  const envelopeArea = 2 * (length * width) + 2 * (length * height) + 2 * (width * height);

  const lambda = 0.032; // W/mK, typical insulation board
  const mult = WALL_MULTIPLIER[wall] ?? 1.0;
  const uValue = (lambda * mult) / (insulation / 1000); // W/m2K
  const deltaT = 20 - climate.temp; // indoor setpoint 20°C

  const heatLossW = uValue * envelopeArea * deltaT;
  const heatLossKW = heatLossW / 1000;
  const dailyEnergyKWh = heatLossKW * 24;

  const gainFactor = ORIENTATION_GAIN[orientation] ?? 0.6;
  const solarGainW = climate.solar * floorArea * gainFactor * 0.3;

  const score = Math.max(0, Math.min(100, 100 - uValue * 9));

  return {
    floorArea, volume, envelopeArea, uValue, heatLossKW, dailyEnergyKWh,
    solarGainW, score,
    breakdown: [
      { name: "Walls", value: +(heatLossKW * 0.55).toFixed(2) },
      { name: "Roof", value: +(heatLossKW * 0.30).toFixed(2) },
      { name: "Floor", value: +(heatLossKW * 0.15).toFixed(2) },
    ],
  };
}

function computeRecommendation(climate, shelter, sim) {
  const recInsulation = Math.max(shelter.insulation, 100);
  const recWall = "Insulated Sandwich Panel";
  const recRoof = "Double-Insulated Cool Roof";
  const recOrientation = "South";

  const recSim = computeSimulation(climate, {
    ...shelter,
    insulation: recInsulation,
    wall: "Insulated Panel",
    orientation: recOrientation,
  });

  const reduction = Math.max(0, ((sim.heatLossKW - recSim.heatLossKW) / sim.heatLossKW) * 100);
  const efficiency = recSim.score >= 80 ? "High" : recSim.score >= 60 ? "Medium" : "Low";
  const comfort = recSim.score >= 80 ? "Excellent" : recSim.score >= 60 ? "Good" : "Fair";

  return {
    recInsulation, recWall, recRoof, recOrientation,
    reduction: reduction.toFixed(0), efficiency, comfort, recScore: recSim.score,
  };
}

/* ------------------------------------------------------------------ */
/*  Small building blocks                                              */
/* ------------------------------------------------------------------ */
function MountainMark({ opacity = 1 }) {
  return (
    <svg width="100%" height="52" viewBox="0 0 220 52" fill="none" style={{ opacity }}>
      <path d="M0 50 L38 14 L62 34 L92 6 L128 40 L150 22 L178 46 L220 12 L220 52 L0 52 Z"
        fill={T.line800} />
      <path d="M38 14 L48 26 L30 26 Z" fill={T.ice400} opacity="0.35" />
      <path d="M92 6 L104 22 L82 22 Z" fill={T.ice400} opacity="0.35" />
    </svg>
  );
}

function FieldLabel({ children }) {
  return (
    <label style={{
      display: "block", fontSize: 12.5, fontWeight: 600, color: T.text600,
      marginBottom: 7, letterSpacing: "0.01em",
    }}>{children}</label>
  );
}

const inputBase = {
  width: "100%", padding: "11px 13px", borderRadius: 10,
  border: `1.5px solid ${T.surfaceAlt}`, background: T.surface,
  fontSize: 14.5, color: T.text900, fontFamily: "'IBM Plex Mono', monospace",
  outline: "none", boxSizing: "border-box", transition: "border-color .15s",
};

function NumberField({ label, value, onChange, unit, step = 1, min = 0 }) {
  return (
    <div>
      <FieldLabel>{label}</FieldLabel>
      <div style={{ position: "relative" }}>
        <input
          type="number" value={value} step={step} min={min}
          onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
          style={{ ...inputBase, paddingRight: 44 }}
          onFocus={(e) => (e.target.style.borderColor = T.ice500)}
          onBlur={(e) => (e.target.style.borderColor = T.surfaceAlt)}
        />
        <span style={{
          position: "absolute", right: 13, top: "50%", transform: "translateY(-50%)",
          fontSize: 12.5, color: T.text400, fontFamily: "'IBM Plex Mono', monospace",
        }}>{unit}</span>
      </div>
    </div>
  );
}

function SelectField({ label, value, options, onChange, icon: Icon }) {
  return (
    <div>
      <FieldLabel>{label}</FieldLabel>
      <div style={{ position: "relative" }}>
        {Icon && <Icon size={16} color={T.text400} style={{ position: "absolute", left: 13, top: 13 }} />}
        <select
          value={value} onChange={(e) => onChange(e.target.value)}
          style={{
            ...inputBase, fontFamily: "'Inter', sans-serif", appearance: "none",
            paddingLeft: Icon ? 38 : 13, cursor: "pointer",
          }}
        >
          {options.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
        <ChevronRight size={15} color={T.text400}
          style={{ position: "absolute", right: 13, top: 13, transform: "rotate(90deg)", pointerEvents: "none" }} />
      </div>
    </div>
  );
}

function Card({ children, style }) {
  return (
    <div style={{
      background: T.surface, borderRadius: 16, border: `1px solid ${T.surfaceAlt}`,
      padding: 22, ...style,
    }}>{children}</div>
  );
}

function PrimaryButton({ children, onClick, disabled, icon: Icon = ArrowRight }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      display: "inline-flex", alignItems: "center", gap: 8,
      background: disabled ? T.text400 : T.navy900, color: "#fff",
      border: "none", borderRadius: 11, padding: "12px 22px",
      fontSize: 14.5, fontWeight: 600, cursor: disabled ? "not-allowed" : "pointer",
      fontFamily: "'Inter', sans-serif", transition: "background .15s",
    }}
      onMouseEnter={(e) => { if (!disabled) e.currentTarget.style.background = T.ice500; }}
      onMouseLeave={(e) => { if (!disabled) e.currentTarget.style.background = T.navy900; }}
    >
      {children} <Icon size={16} />
    </button>
  );
}

function GhostButton({ children, onClick, icon: Icon = ArrowLeft }) {
  return (
    <button onClick={onClick} style={{
      display: "inline-flex", alignItems: "center", gap: 8,
      background: "transparent", color: T.text600,
      border: `1.5px solid ${T.surfaceAlt}`, borderRadius: 11, padding: "12px 20px",
      fontSize: 14.5, fontWeight: 600, cursor: "pointer", fontFamily: "'Inter', sans-serif",
    }}>
      <Icon size={16} /> {children}
    </button>
  );
}

function MetricCard({ icon: Icon, label, value, unit, accent }) {
  return (
    <Card style={{ display: "flex", flexDirection: "column", gap: 14, minHeight: 128 }}>
      <div style={{
        width: 38, height: 38, borderRadius: 10, background: accent + "1A",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>
        <Icon size={19} color={accent} />
      </div>
      <div>
        <div style={{ fontSize: 12.5, color: T.text600, fontWeight: 600, marginBottom: 4 }}>{label}</div>
        <div style={{ fontSize: 26, fontWeight: 700, color: T.text900, fontFamily: "'IBM Plex Mono', monospace" }}>
          {value}<span style={{ fontSize: 15, color: T.text400, marginLeft: 4 }}>{unit}</span>
        </div>
      </div>
    </Card>
  );
}

function ResultTile({ label, value, unit }) {
  return (
    <div style={{
      background: T.surfaceAlt, borderRadius: 12, padding: "14px 16px",
    }}>
      <div style={{ fontSize: 11.5, fontWeight: 600, color: T.text600, marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 19, fontWeight: 700, color: T.text900, fontFamily: "'IBM Plex Mono', monospace" }}>
        {value} <span style={{ fontSize: 12.5, color: T.text400, fontWeight: 500 }}>{unit}</span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Sidebar                                                             */
/* ------------------------------------------------------------------ */
function Sidebar({ step, maxStep, onNavigate }) {
  return (
    <div style={{
      width: 264, minWidth: 264, background: T.navy950, height: "100%",
      display: "flex", flexDirection: "column", padding: "28px 20px",
      boxSizing: "border-box", fontFamily: "'Inter', sans-serif",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4, padding: "0 4px" }}>
        <div style={{
          width: 34, height: 34, borderRadius: 9, background: T.ice400,
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <Home size={17} color={T.navy950} />
        </div>
        <div>
          <div style={{ color: "#fff", fontWeight: 700, fontSize: 15.5, lineHeight: 1.15 }}>Smart Shelter AI</div>
          <div style={{ color: T.text400, fontSize: 11, fontWeight: 500 }}>Climate Engineering Simulator</div>
        </div>
      </div>

      <div style={{ height: 1, background: T.line800, margin: "24px 4px 20px" }} />

      <nav style={{ display: "flex", flexDirection: "column", gap: 4, flex: 1 }}>
        {STEPS.map((s) => {
          const isActive = s.id === step;
          const isDone = s.id < maxStep || (s.id === maxStep && step > s.id);
          const isReachable = s.id <= maxStep;
          const Icon = s.icon;
          return (
            <button
              key={s.id}
              disabled={!isReachable}
              onClick={() => isReachable && onNavigate(s.id)}
              style={{
                display: "flex", alignItems: "center", gap: 12,
                background: isActive ? T.navy800 : "transparent",
                border: "none", borderRadius: 11, padding: "11px 12px",
                cursor: isReachable ? "pointer" : "default", textAlign: "left",
                borderLeft: isActive ? `3px solid ${T.ice400}` : "3px solid transparent",
              }}
            >
              <div style={{
                width: 26, height: 26, borderRadius: 7, flexShrink: 0,
                background: isActive ? T.ice400 : isDone ? T.line800 : "transparent",
                border: !isActive && !isDone ? `1.5px solid ${T.line800}` : "none",
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                {isDone && !isActive ? (
                  <CheckCircle2 size={14} color={T.ice300} />
                ) : (
                  <span style={{
                    fontSize: 11.5, fontWeight: 700, fontFamily: "'IBM Plex Mono', monospace",
                    color: isActive ? T.navy950 : T.text400,
                  }}>{s.id}</span>
                )}
              </div>
              <span style={{
                fontSize: 13.5, fontWeight: isActive ? 600 : 500,
                color: isActive ? "#fff" : isReachable ? T.text400 : "#3E4E58",
              }}>{s.label}</span>
              <Icon size={14} color={isActive ? T.ice300 : "transparent"} style={{ marginLeft: "auto" }} />
            </button>
          );
        })}
      </nav>

      <div style={{ marginTop: "auto" }}>
        <MountainMark opacity={0.9} />
        <div style={{ height: 1, background: T.line800, margin: "16px 4px" }} />
        <div style={{ color: T.text400, fontSize: 10.5, padding: "0 4px", lineHeight: 1.5 }}>
          B.Tech Engineering Project<br />AI-Assisted Shelter Design for Extreme Climates
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Screen shell                                                       */
/* ------------------------------------------------------------------ */
function ScreenShell({ eyebrow, title, subtitle, children }) {
  return (
    <div style={{ maxWidth: 860, margin: "0 auto", padding: "44px 40px 60px" }}>
      <div style={{ marginBottom: 30 }}>
        <div style={{ color: T.ice500, fontSize: 12.5, fontWeight: 700, marginBottom: 8 }}>{eyebrow}</div>
        <h1 style={{ fontSize: 30, fontWeight: 700, color: T.text900, margin: "0 0 8px" }}>{title}</h1>
        {subtitle && <p style={{ fontSize: 15, color: T.text600, margin: 0 }}>{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Screen 1 — Location                                                 */
/* ------------------------------------------------------------------ */
function LocationScreen({ location, setLocation, onNext }) {
  return (
    <ScreenShell eyebrow="STEP 1 OF 5" title="Location"
      subtitle="Select the location for shelter simulation.">
      <Card style={{ maxWidth: 460 }}>
        <SelectField label="Site location" value={location} options={LOCATIONS}
          onChange={setLocation} icon={MapPin} />
        <p style={{ fontSize: 13, color: T.text400, marginTop: 14, lineHeight: 1.5 }}>
          Climate data for the selected site — temperature, solar radiation, wind speed
          and humidity — will be loaded automatically in the next step.
        </p>
      </Card>
      <div style={{ marginTop: 28 }}>
        <PrimaryButton onClick={onNext}>Continue</PrimaryButton>
      </div>
    </ScreenShell>
  );
}

/* ------------------------------------------------------------------ */
/*  Screen 2 — Climate                                                  */
/* ------------------------------------------------------------------ */
function ClimateScreen({ location, climate, onBack, onNext }) {
  return (
    <ScreenShell eyebrow="STEP 2 OF 5" title="Climate Conditions"
      subtitle={`Site conditions recorded for ${location}.`}>
      <div style={{
        display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 16,
      }}>
        <MetricCard icon={Thermometer} label="Temperature" value={climate.temp} unit="°C" accent={T.ice500} />
        <MetricCard icon={Sun} label="Solar Radiation" value={climate.solar} unit="W/m²" accent={T.amber500} />
        <MetricCard icon={Wind} label="Wind Speed" value={climate.wind} unit="m/s" accent={T.text600} />
        <MetricCard icon={Droplets} label="Humidity" value={climate.humidity} unit="%" accent="#4C8FBF" />
      </div>
      <div style={{ display: "flex", gap: 12, marginTop: 30 }}>
        <GhostButton onClick={onBack}>Back</GhostButton>
        <PrimaryButton onClick={onNext}>Continue</PrimaryButton>
      </div>
    </ScreenShell>
  );
}

/* ------------------------------------------------------------------ */
/*  Screen 3 — Shelter Design                                           */
/* ------------------------------------------------------------------ */
function ShelterScreen({ shelter, setShelter, onBack, onRun }) {
  const set = (k) => (v) => setShelter((s) => ({ ...s, [k]: v }));
  return (
    <ScreenShell eyebrow="STEP 3 OF 5" title="Shelter Design"
      subtitle="Define the physical and material parameters of the shelter.">
      <Card>
        <div style={{ fontSize: 12.5, fontWeight: 700, color: T.text600, marginBottom: 16 }}>DIMENSIONS</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 26 }}>
          <NumberField label="Length" value={shelter.length} unit="m" onChange={set("length")} />
          <NumberField label="Width" value={shelter.width} unit="m" onChange={set("width")} />
          <NumberField label="Height" value={shelter.height} unit="m" onChange={set("height")} />
        </div>

        <div style={{ fontSize: 12.5, fontWeight: 700, color: T.text600, marginBottom: 16 }}>ENVELOPE</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 16, marginBottom: 16 }}>
          <SelectField label="Orientation" value={shelter.orientation} options={ORIENTATIONS}
            onChange={set("orientation")} icon={Compass} />
          <NumberField label="Insulation Thickness" value={shelter.insulation} unit="mm" step={5}
            onChange={set("insulation")} />
          <SelectField label="Wall Type" value={shelter.wall} options={WALL_TYPES}
            onChange={set("wall")} icon={Layers} />
          <SelectField label="Roof Type" value={shelter.roof} options={ROOF_TYPES}
            onChange={set("roof")} icon={Home} />
        </div>
      </Card>
      <div style={{ display: "flex", gap: 12, marginTop: 28 }}>
        <GhostButton onClick={onBack}>Back</GhostButton>
        <PrimaryButton onClick={onRun} icon={ArrowRight}>Run Simulation</PrimaryButton>
      </div>
    </ScreenShell>
  );
}

/* ------------------------------------------------------------------ */
/*  Screen 4 — Simulation                                               */
/* ------------------------------------------------------------------ */
function SimulationScreen({ location, climate, shelter, sim, progress, done, onBack, onNext }) {
  const gaugeData = [{ name: "score", value: sim.score, fill: T.ice400 }];
  return (
    <ScreenShell eyebrow="STEP 4 OF 5" title="Simulation"
      subtitle={`Running thermal and energy simulation for ${location}.`}>

      <Card style={{ marginBottom: 20 }}>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "10px 28px", fontSize: 13 }}>
          <span style={{ color: T.text600 }}>Site: <b style={{ color: T.text900 }}>{location}</b></span>
          <span style={{ color: T.text600 }}>Outdoor Temp: <b style={{ color: T.text900 }}>{climate.temp}°C</b></span>
          <span style={{ color: T.text600 }}>Dimensions: <b style={{ color: T.text900 }}>{shelter.length}×{shelter.width}×{shelter.height} m</b></span>
          <span style={{ color: T.text600 }}>Orientation: <b style={{ color: T.text900 }}>{shelter.orientation}</b></span>
          <span style={{ color: T.text600 }}>Insulation: <b style={{ color: T.text900 }}>{shelter.insulation} mm</b></span>
        </div>
      </Card>

      {!done ? (
        <Card style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16, padding: 40 }}>
          <Loader2 size={30} color={T.ice500} className="spin" />
          <div style={{ fontSize: 14, color: T.text600, fontWeight: 600 }}>Running climate &amp; thermal simulation…</div>
          <div style={{ width: "100%", maxWidth: 360, height: 8, background: T.surfaceAlt, borderRadius: 6, overflow: "hidden" }}>
            <div style={{ width: `${progress}%`, height: "100%", background: T.ice400, transition: "width .2s linear" }} />
          </div>
          <div style={{ fontSize: 12.5, color: T.text400, fontFamily: "'IBM Plex Mono', monospace" }}>{progress}%</div>
        </Card>
      ) : (
        <>
          <div style={{
            display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px,1fr))", gap: 12, marginBottom: 20,
          }}>
            <ResultTile label="Floor Area" value={sim.floorArea.toFixed(1)} unit="m²" />
            <ResultTile label="Shelter Volume" value={sim.volume.toFixed(1)} unit="m³" />
            <ResultTile label="Heat Loss" value={sim.heatLossKW.toFixed(2)} unit="kW" />
            <ResultTile label="Daily Energy Req." value={sim.dailyEnergyKWh.toFixed(1)} unit="kWh/day" />
            <ResultTile label="Solar Gain" value={sim.solarGainW.toFixed(0)} unit="W" />
            <ResultTile label="Thermal Performance" value={sim.score.toFixed(0)} unit="/ 100" />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }}>
            <Card>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: T.text600, marginBottom: 10 }}>
                HEAT LOSS BY COMPONENT (kW)
              </div>
              <ResponsiveContainer width="100%" height={190}>
                <BarChart data={sim.breakdown} barSize={44}>
                  <CartesianGrid strokeDasharray="3 3" stroke={T.surfaceAlt} vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 12, fill: T.text600 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: T.text400 }} axisLine={false} tickLine={false} />
                  <Tooltip cursor={{ fill: T.surfaceAlt }} contentStyle={{ borderRadius: 10, border: `1px solid ${T.surfaceAlt}`, fontSize: 12.5 }} />
                  <Bar dataKey="value" fill={T.ice400} radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            <Card style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: T.text600, marginBottom: 6, alignSelf: "flex-start" }}>
                THERMAL PERFORMANCE
              </div>
              <ResponsiveContainer width="100%" height={170}>
                <RadialBarChart innerRadius="70%" outerRadius="100%" data={gaugeData} startAngle={90} endAngle={-270}>
                  <PolarAngleAxis type="number" domain={[0, 100]} angleAxisId={0} tick={false} />
                  <RadialBar background={{ fill: T.surfaceAlt }} dataKey="value" cornerRadius={8} />
                </RadialBarChart>
              </ResponsiveContainer>
              <div style={{ marginTop: -110, fontSize: 26, fontWeight: 700, color: T.text900, fontFamily: "'IBM Plex Mono', monospace" }}>
                {sim.score.toFixed(0)}
              </div>
              <div style={{ marginTop: 68, fontSize: 12, color: T.text400, fontWeight: 600 }}>out of 100</div>
            </Card>
          </div>
        </>
      )}

      <div style={{ display: "flex", gap: 12, marginTop: 28 }}>
        <GhostButton onClick={onBack}>Back</GhostButton>
        <PrimaryButton onClick={onNext} disabled={!done}>View Recommendation</PrimaryButton>
      </div>
    </ScreenShell>
  );
}

/* ------------------------------------------------------------------ */
/*  Screen 5 — Recommendation                                           */
/* ------------------------------------------------------------------ */
function RecommendationScreen({ rec, onRestart }) {
  const rows = [
    { label: "Recommended Orientation", value: rec.recOrientation, icon: Compass },
    { label: "Recommended Wall", value: rec.recWall, icon: Layers },
    { label: "Recommended Roof", value: rec.recRoof, icon: Home },
    { label: "Recommended Insulation", value: `${rec.recInsulation} mm`, icon: Ruler },
  ];
  return (
    <ScreenShell eyebrow="STEP 5 OF 5" title="Recommendation"
      subtitle="AI-generated design guidance based on the simulation results.">

      <Card style={{
        borderColor: T.amber500 + "55", background: `linear-gradient(180deg, ${T.amber500}0D, ${T.surface})`,
        marginBottom: 20,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 18 }}>
          <div style={{
            width: 34, height: 34, borderRadius: 9, background: T.amber500 + "22",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <Lightbulb size={17} color={T.amber500} />
          </div>
          <div style={{ fontSize: 15.5, fontWeight: 700, color: T.text900 }}>Engineering Recommendation</div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px,1fr))", gap: 14 }}>
          {rows.map((r) => (
            <div key={r.label} style={{ background: T.surface, borderRadius: 12, padding: 16, border: `1px solid ${T.surfaceAlt}` }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                <r.icon size={15} color={T.ice500} />
                <span style={{ fontSize: 11.5, fontWeight: 600, color: T.text600 }}>{r.label}</span>
              </div>
              <div style={{ fontSize: 16.5, fontWeight: 700, color: T.text900 }}>{r.value}</div>
            </div>
          ))}
        </div>
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px,1fr))", gap: 16 }}>
        <Card style={{ textAlign: "center" }}>
          <TrendingDown size={22} color={T.good} style={{ marginBottom: 8 }} />
          <div style={{ fontSize: 26, fontWeight: 700, color: T.text900, fontFamily: "'IBM Plex Mono', monospace" }}>{rec.reduction}%</div>
          <div style={{ fontSize: 12.5, color: T.text600, fontWeight: 600, marginTop: 4 }}>Expected Heat-Loss Reduction</div>
        </Card>
        <Card style={{ textAlign: "center" }}>
          <Zap size={22} color={T.amber500} style={{ marginBottom: 8 }} />
          <div style={{ fontSize: 22, fontWeight: 700, color: T.text900 }}>{rec.efficiency}</div>
          <div style={{ fontSize: 12.5, color: T.text600, fontWeight: 600, marginTop: 4 }}>Energy Efficiency</div>
        </Card>
        <Card style={{ textAlign: "center" }}>
          <Thermometer size={22} color={T.ice500} style={{ marginBottom: 8 }} />
          <div style={{ fontSize: 22, fontWeight: 700, color: T.text900 }}>{rec.comfort}</div>
          <div style={{ fontSize: 12.5, color: T.text600, fontWeight: 600, marginTop: 4 }}>Thermal Comfort</div>
        </Card>
      </div>

      <div style={{ marginTop: 30 }}>
        <PrimaryButton onClick={onRestart} icon={RotateCcw}>Start New Simulation</PrimaryButton>
      </div>
    </ScreenShell>
  );
}

/* ------------------------------------------------------------------ */
/*  App                                                                 */
/* ------------------------------------------------------------------ */
export default function SmartShelterAI() {
  const [step, setStep] = useState(1);
  const [maxStep, setMaxStep] = useState(1);
  const [location, setLocation] = useState("Ladakh");
  const [shelter, setShelter] = useState({
    length: 5, width: 4, height: 3, orientation: "South",
    wall: "Insulated Panel", roof: "Insulated Roof", insulation: 50,
  });
  const [progress, setProgress] = useState(0);
  const [simDone, setSimDone] = useState(false);
  const timerRef = useRef(null);

  const climate = CLIMATE_PRESETS[location];
  const sim = useMemo(() => computeSimulation(climate, shelter), [climate, shelter]);
  const rec = useMemo(() => computeRecommendation(climate, shelter, sim), [climate, shelter, sim]);

  const goTo = (n) => setStep(n);
  const advance = (n) => { setStep(n); setMaxStep((m) => Math.max(m, n)); };

  const runSimulation = () => {
    setSimDone(false);
    setProgress(0);
    advance(4);
    clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) { clearInterval(timerRef.current); setSimDone(true); return 100; }
        return p + Math.round(6 + Math.random() * 10);
      });
    }, 160);
  };

  useEffect(() => () => clearInterval(timerRef.current), []);

  const restart = () => {
    clearInterval(timerRef.current);
    setStep(1); setMaxStep(1);
    setLocation("Ladakh");
    setShelter({ length: 5, width: 4, height: 3, orientation: "South", wall: "Insulated Panel", roof: "Insulated Roof", insulation: 50 });
    setProgress(0); setSimDone(false);
  };

  return (
    <div style={{ width: "100%", height: "100vh", display: "flex", background: T.bgApp, fontFamily: "'Inter', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600;700&display=swap');
        * { font-family: 'Inter', sans-serif; }
        select { font-family: 'Inter', sans-serif; }
        .spin { animation: spin 1s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-thumb { background: #C7D2D5; border-radius: 8px; }
      `}</style>

      <Sidebar step={step} maxStep={maxStep} onNavigate={goTo} />

      <div style={{ flex: 1, overflowY: "auto" }}>
        {step === 1 && (
          <LocationScreen location={location} setLocation={setLocation} onNext={() => advance(2)} />
        )}
        {step === 2 && (
          <ClimateScreen location={location} climate={climate} onBack={() => goTo(1)} onNext={() => advance(3)} />
        )}
        {step === 3 && (
          <ShelterScreen shelter={shelter} setShelter={setShelter} onBack={() => goTo(2)} onRun={runSimulation} />
        )}
        {step === 4 && (
          <SimulationScreen
            location={location} climate={climate} shelter={shelter} sim={sim}
            progress={progress} done={simDone}
            onBack={() => goTo(3)} onNext={() => advance(5)}
          />
        )}
        {step === 5 && (
          <RecommendationScreen rec={rec} onRestart={restart} />
        )}
      </div>
    </div>
  );
}
